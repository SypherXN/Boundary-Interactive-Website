Fly Exterminator / Boundary Interactive — press kit assets
https://sypherxn.github.io/Boundary-Interactive-Website/press/

Includes logos, key art, UI screenshot, and room-scan image.
Trailer: https://www.youtube.com/watch?v=pCl-uN2TTYY
Press: flyexterminatorgame@gmail.com
